<!DOCTYPE html>
<h2 align="center">
<hr>
🚀Mini XLite Autoscript By Vinstechmy 🚀
<h2><hr>
  
<h2 align="center"> ♦️Supported Linux Distribution♦️</h2>
<p align="center"><img src="https://d33wubrfki0l68.cloudfront.net/5911c43be3b1da526ed609e9c55783d9d0f6b066/9858b/assets/img/debian-ubuntu-hover.png"width="400"></p>
<p align="center"><img src="https://img.shields.io/static/v1?style=for-the-badge&logo=debian&label=Debian%2010&message=Buster&color=blue"> <img src="https://img.shields.io/static/v1?style=for-the-badge&logo=ubuntu&label=Ubuntu%2018&message=18.04 LTS&color=blue"></p>
  
<p align="center"><img src="https://img.shields.io/badge/Service-Multiport (XRAY)-orange"></p>
  
## ⏩ MINI XLITE AUTOSCRIPT DETAILS ⏪
<b>
[ VPN SERVICES ] <br>
<br>
✅ XRAY VLESS WEBSOCKET TLS (443) & NON-TLS (80/8080/8880) <br>
✅ XRAY TROJAN WEBSOCKET TLS (443) & NON-TLS (80/8080/8880) <br>
✅ XRAY VLESS TCP XTLS (443) <br>
✅ XRAY TROJAN TCP (443) <br>
<br>
[ OTHER SERVICES ] <br>
<br>
✅ SUPPORT CUSTOM PATH FOR VLESS TLS & NTLS <br>
✅ CREATE TRIAL VPN ACCOUNT <br>
✅ CHECK VPN STATUS <br>
✅ CHECK VPN PORT <br>
✅ CHECK RAM USAGE <br>
✅ AUTOSCRIPT UPDATE <br>
✅ NETFLIX REGION CHECKER <br>
✅ CHECK LOGIN USER <br>
✅ CHECK CREATED CONFIG <br>
✅ AUTOMATIC CLEAR LOG <br>
✅ AUTOMATIC VPS REBOOT <br>
✅ BACKUP VPS DATA BY TELEGRAM BOT <br>
✅ BACKUP & RESTORE <br></br>

♦️ For Debian 10 Only For First Time Installation (Update Repo) <br>

  ```html
 apt update -y && apt upgrade -y && apt dist-upgrade -y && reboot
  ```
  ♦️ For Ubuntu 18.04 Only For First Time Installation (Update Repo) <br>
  
  ```html
 apt-get update && apt-get upgrade -y && apt dist-upgrade -y && update-grub && reboot
 ```
♦️ Installation Link<br>

  ```html
sysctl -w net.ipv6.conf.all.disable_ipv6=1 && sysctl -w net.ipv6.conf.default.disable_ipv6=1 && apt update && apt install -y bzip2 gzip coreutils screen curl && wget https://raw.githubusercontent.com/vinstechmy/MiniXLiteAutoscript/main/V1/setup.sh && chmod +x setup.sh && ./setup.sh
  ```

</b>

## ⏩ MINI XLITE AUTOSCRIPT EXAMPLE ⏪
<b>
</b>
<br>

</b>
<p align="center">
<img src="https://user-images.githubusercontent.com/82468311/211945486-1f7ca8b9-1084-4739-bb95-078cad94477b.png" width="400" title="Autoscript-Lite">
</p>

</b>
<p align="center">
<img src="https://user-images.githubusercontent.com/82468311/211945563-7f9ceb5b-1430-43e3-8afd-a058d3db0a8c.png" width="400" title="Autoscript-Lite">
</p>

## ⏩ BUY ME A COFFEE ? ⏪
<b>
<br>
<p align="center">
<img src="https://user-images.githubusercontent.com/82468311/189573622-9b165a67-4ae7-4354-bd8d-5fad54c266fa.JPG" width="300" title="Autoscript-Lite">
<b>
